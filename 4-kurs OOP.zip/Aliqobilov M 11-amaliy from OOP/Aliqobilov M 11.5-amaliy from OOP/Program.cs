﻿string s = ""; s=Console.ReadLine();
bool b = true;
for(int i = 1; i < s.Length; i++)
{
    if ((s[i] >= 'a' && s[i] <= 'z') && (s[i] - s[i-1] != 1)) { Console.WriteLine(s[i]); b=false ;  return; }
}
if(b)Console.WriteLine(-1);