﻿using System;
namespace std
{
    public class Program
    {
        public static void Main(string[] args)
        {
            string s="";s=Console.ReadLine();
            int firstind = s.IndexOf(' ');
            s=s.Remove(firstind,1);
            int secondind = s.IndexOf(' ');
            Console.WriteLine(s.Substring(firstind,secondind-firstind));
        }
    }
}