﻿string[] s = Console.ReadLine().Split(' ');
int maxlength = 0;
foreach(string i in s)
{
    if(i.Length>maxlength) maxlength = i.Length;
}
Console.WriteLine(maxlength.ToString());