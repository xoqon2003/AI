﻿string[] s = Console.ReadLine().Split(' ');
foreach (string s2 in s)Console.Write(s2);