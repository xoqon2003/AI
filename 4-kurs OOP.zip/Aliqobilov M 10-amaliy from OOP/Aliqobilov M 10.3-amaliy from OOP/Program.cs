﻿//Random rn = new Random();

//Console.Write("n:\t");
//int n = Convert.ToInt32(Console.ReadLine());
//Console.Write("m:\t");
//int m = Convert.ToInt32(Console.ReadLine());

//int[,] a = new int[n, m];
//int max = 0, maxi = 0;
//for (int i = 0; i < n; i++)
//{
//    for (int j = 0; j < m; j++)
//    {
//        a[i, j] = rn.Next() % 20;
//        Console.Write(a[i, j] + "  ");
//    }
//    Console.WriteLine();
//}
//Console.WriteLine();
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Xceed.Document.NET;
using Paragraph = DocumentFormat.OpenXml.Wordprocessing.Paragraph;

// Docx faylni o'qish uchun funksiya
static void ReadDocxFile(string filePath)
{
    // Docx faylni ochish
    using (WordprocessingDocument doc = WordprocessingDocument.Open(filePath, false))
    {
        // Dokumentning barcha paragraflarni olish
        var paragraphs = doc.MainDocumentPart.Document.Descendants<Paragraph>();

        // Barcha paragraflarni chiqarishz
        string s = " ";

        foreach (var paragraph in paragraphs)
        {
            // Console.WriteLine(paragraph.InnerText);
            s += paragraph.InnerText+"\n";
        }
        Console.WriteLine(s);       
    }
}
string filePath = "C:\\Users\\theo\\Desktop\\a.docx";
ReadDocxFile(filePath);