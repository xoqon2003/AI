﻿Random rn = new Random();

Console.Write("n:\t");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m:\t");
int m = Convert.ToInt32(Console.ReadLine());

int[,]a=new int[n,m];
int max = 0, maxi = 0;
for (int i = 0; i < n; i++)
{
    int s = 0;
    for (int j = 0; j < m; j++)
    {
        Console.Write("a[" + (i + 1) + "][" + (j + 1) + "]=\t");
        a[i,j] += Convert.ToInt32(Console.ReadLine());
        s += a[i, j];
    }
    if(s > max)
    {
        max= s;
        maxi=i;
    }
}

Console.Write("Siz kiritgan massivdagi eng yig`indisi katta satrning \nindeksi:\t" + maxi + "\nSatr yig`indisi esa:\t" + max);