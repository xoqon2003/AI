﻿Random rn = new Random();

Console.Write("n:\t");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m:\t");
int m = Convert.ToInt32(Console.ReadLine());

int[,] a = new int[n, m];
int max = 0, maxi = 0;
for (int i = 0; i < n; i++)
{
    for (int j = 0; j < m; j++)
    {
        a[i, j] = rn.Next() % 20;
        Console.Write(a[i, j] + "  ");
    }
    Console.WriteLine();
}
Console.WriteLine();

for (int i = 0; i < m; i++)
{
    int s = 0;
    for (int j = 0; j < n; j++)
    {
        s += a[j, i];
    }
    if (s > max)
    {
        max = s;
        maxi = i;
    }
    Console.WriteLine();
}

Console.Write("\nSiz kiritgan massivdagi eng yig`indisi katta ustunning \nindeksi:\t\t" + (maxi) + "\nSatr yig`indisi esa:\t" + max);
Console.WriteLine("\n\n");