﻿Console.Write("n=");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m=");
int m = Convert.ToInt32(Console.ReadLine());

string probs = "";
int l = m, r = m;

for (int i = 1; i <= m; i++) probs += " ";
int cnt=1;

for(int i = 0; i < n; i++)
{
    Console.Write(probs);
    for (int j = 0; j < cnt; j++) 
        Console.Write(" *");
    probs=probs.Remove(probs.LastIndexOf(' '),1);
    cnt++;
    Console.WriteLine();
}