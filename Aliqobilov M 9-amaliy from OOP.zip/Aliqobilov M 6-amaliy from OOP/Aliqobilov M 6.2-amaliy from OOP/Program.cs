﻿Console.Write("n=");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m=");
int m = Convert.ToInt32(Console.ReadLine());

for (int i = 0; i < n; i++)
{
    for (int j = m - 1; j >= 0; j--)
    {
        Console.Write(" *");
        if (i == j) break;
    }
    Console.WriteLine();
}