﻿Console.Write("n=");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m=");
int m = Convert.ToInt32(Console.ReadLine());

string probs = "";

for(int i = 0; i < n; i++)
{
    Console.Write(probs);
    for(int j=0;j< m; j++)
    {
        Console.Write("* ");
    }
    m--;
    probs += " ";   
    Console.WriteLine();
}