﻿Console.Write("n=");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m=");
int m = Convert.ToInt32(Console.ReadLine());

for (int i = 0; i < n; i++)
{
    for (int j = 0; j < m; j++)
    {
        if (i + j < (n - 1 + m - 1) / 2)
        {
            Console.Write("  ");
        }
        else Console.Write(" *");
    }
    Console.WriteLine();
}

for (int i = 0; i < n; i++)
{
    for (int j = m; j > 0; j--)
    {
        if (i + j >= (n + m) / 2)
        {
            Console.Write("  ");
        }
        else Console.Write(" *");
    }
    Console.WriteLine();
}