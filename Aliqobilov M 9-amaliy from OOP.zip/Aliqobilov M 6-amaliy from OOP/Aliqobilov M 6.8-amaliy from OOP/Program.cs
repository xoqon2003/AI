﻿Console.Write("n=");
int n = Convert.ToInt32(Console.ReadLine());
Console.Write("m=");
int m = Convert.ToInt32(Console.ReadLine());

int cnt = 1;
bool incrordecr=false;

for(int i = 0; i < 2*n-1; i++)
{
    for(int j = 0; j < cnt; j++)
    {
        if ((i + j) % 2 == 0)
        {
            Console.Write("*");
        }
        else Console.Write(" ");
    }
    Console.WriteLine();
    if (i == n - 1) incrordecr = true;
    cnt=incrordecr? --cnt: ++cnt;
}