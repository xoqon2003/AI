﻿int x1, x2, y1, y2;
Console.Write("x1=\t");
x1 = Convert.ToInt32(Console.ReadLine());

Console.Write("y1=\t");
y1 = Convert.ToInt32(Console.ReadLine());

Console.Write("x2=\t");
x2 = Convert.ToInt32(Console.ReadLine());

Console.Write("y2=\t");
y2 = Convert.ToInt32(Console.ReadLine());

if (Math.Abs(x2 - x1) == Math.Abs(y2 - y1))
{
    Console.Write("Yes");
}

else Console.Write("No");