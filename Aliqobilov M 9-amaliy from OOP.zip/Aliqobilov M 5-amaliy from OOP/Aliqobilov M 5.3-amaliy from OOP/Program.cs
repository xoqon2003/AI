﻿using System;

class NBS
{
    static int bol_son(int n)
    {
        int cnt = 0;
        for (int i = 1; i <= Math.Sqrt(n);i++)
        {
            if (n % i == 0)
            {
                if (n / i == i)
                    cnt++;
          
                else
                    cnt = cnt + 2;
            }
        }

        return cnt;
    }
    public static void Main()
    {
        int n;
        Console.Write("N:\t");
        n = Convert.ToInt32(Console.ReadLine());
        Console.Write(bol_son(n));
    }
}