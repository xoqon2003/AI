﻿int x1, x2, y1, y2;
Console.Write("x1=\t");
x1=Convert.ToInt32(Console.ReadLine());

Console.Write("y1=\t");
y1 = Convert.ToInt32(Console.ReadLine());

Console.Write("x2=\t");
x2 = Convert.ToInt32(Console.ReadLine());

Console.Write("x2=\t");
y2 = Convert.ToInt32(Console.ReadLine());

if ((x1 == x2 && y1 != y2) || (x1 != x2 && y1 == y2))
{
    Console.Write("Yes");
}

else Console.Write("No");