﻿string[] s=Console.ReadLine().Split(' ');
int max = 0;

foreach(string i in s)
{
    if (i == "0") break;
    if (Convert.ToInt32(i) > max)
    {
        max = Convert.ToInt32(i);
    }
}

Console.WriteLine(max);