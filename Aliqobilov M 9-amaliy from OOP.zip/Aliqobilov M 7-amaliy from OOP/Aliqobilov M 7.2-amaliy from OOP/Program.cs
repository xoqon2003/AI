﻿string[] s = Console.ReadLine().Split();

int mx = 0;
for(int i =0; i < s.Length; i++)
{
    if (s[i] == "0") break;
    else
    {
        if (Convert.ToInt32(s[i]) > mx) mx = Convert.ToInt32(s[i]);
    }
}

Console.WriteLine(mx);