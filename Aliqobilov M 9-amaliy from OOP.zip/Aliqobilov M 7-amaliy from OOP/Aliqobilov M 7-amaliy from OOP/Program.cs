﻿using System.Runtime.Intrinsics.X86;

Console.Write("a:\t");
int n=Convert.ToInt32(Console.ReadLine());
int[]a=new int[n];

for(int i = 0; i < n; i++)
{
    Console.Write("a["+(i+1)+"]=\t");
    a[i] = Convert.ToInt32(Console.ReadLine());
}

Console.Write("k:\t");
int k=Convert.ToInt32(Console.ReadLine());

int cnt = 0;string probs = "";

foreach (int i in a)
{
    Console.Write(i + " ");
    if (i == k) cnt++;
    if (i < k) probs += " ";
}
Console.WriteLine("\n"+cnt);
