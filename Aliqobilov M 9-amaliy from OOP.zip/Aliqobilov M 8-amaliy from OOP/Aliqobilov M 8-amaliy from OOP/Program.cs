﻿int n = Convert.ToInt32(Console.ReadLine());
int[]a=new int[n];

Random rn=new Random();

for(int i = 0; i < n; i++)
{
    a[i] = rn.Next() % 10;
    Console.Write(a[i]+" ");
}
Console.WriteLine();
for(int i = 0; i < n; i++)
{
    for(int j = 0; j < n-1; j++)
    {
        if (a[j] > a[j + 1])
        {
            int b = a[j];
            a[j] = a[j + 1];
            a[j + 1] = b;
        }
    }
}

for (int i = 0; i < n; i++)
{
    Console.Write(a[i] + " ");
}

Console.WriteLine();

for (int i = 0; i < n; i ++)
{
    Console.Write((a[i] % 2 == 0 ? -1 : a[i])+" ");
}