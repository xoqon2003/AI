﻿Console.Write("a:\t");
int n=Convert.ToInt32(Console.ReadLine());

int[]a=new int[n];

Random rn=new Random();
for (int i = 0; i < n; i++)
{
    a[i] = rn.Next() % 10;
}
foreach (int i in a) Console.Write(a[i] + " ");
Console.WriteLine();


for (int i = 0; i < n - 1; i++)
{
    int mini = i;
    for (int j = i + 1; j < n; j++)
    {
        if (a[j] < a[mini])
        {
            mini = j;
        }
    }
    int b = a[mini];
    a[mini] = a[i];
    a[i] = b;
}

foreach(int i in a)Console.Write(a[i]+" ");
Console.WriteLine();

foreach (int i in a) Console.Write((a[i] % 2 == 0 ? 0 : a[i]) + " ");
