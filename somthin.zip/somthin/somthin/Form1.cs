﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace somthin
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog di = new OpenFileDialog();
            if(di.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = Path.GetFileName(di.FileName);
                label1.Text = Path.GetFullPath(di.FileName);
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog di = new OpenFileDialog();
            if (di.ShowDialog() == DialogResult.OK)
            {
                textBox2.Text = Path.GetFileName(di.FileName);
                label2.Text = Path.GetFullPath(di.FileName);
            }
        }
        private string readfil(string path)
        {
            string text = "";
            try
            {
                using (StreamReader sr = new StreamReader(path))
                {
                    text = sr.ReadToEnd();
                }
            }
            catch(Exception ex) 
            {
                MessageBox.Show(ex.Message);
            }
            return text;
        }
        private void thirdfile()
        {
            string text1=readfil(label1.Text);
            string text2=readfil(label2.Text);
            List<string> list = new List<string>();
            List<string> list1 = new List<string>();
            string [] s=text1.Split('n');
            //MessageBox.Show(text1);
            string ss = "";
            int cnt = 0;
            foreach (string i in text1.Split('\n'))
            {
                if (!i.StartsWith("\t"))
                {
                    cnt++;
                }
                if (cnt>1)
                {
                    cnt = 1;
                    list.Add(ss);
                    ss = "";
                }
                if(i!="")ss += i;
            }

            cnt = 0;
            foreach (string i in text2.Split('\n'))
            {
                if (!i.StartsWith("\t"))
                {
                    cnt++;
                }
                if (cnt > 1)
                {
                    cnt = 1;
                    list1.Add(ss);
                    ss = "";
                }
                if (i != "") ss += i;
            }
            for(int i=0; i<list.Count; i++)
            {
                for(int j = 0; j < list1.Count; j++)
                {
                    if (list[i].Split('\n')[0]== list[i].Split('\n')[0])
                    {
                        
                    }
                }
            }
            //MessageBox.Show(ss);
        }
        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if(textBox3.Text != "")
            {
                button3.Enabled = true;
            }
            else button3.Enabled = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            thirdfile();
        }
    }
}
